<?php
function sendNotifications() {
  // Build notification payload
  $body = array(
    'to' => "u2STJJky0k9DI05Vx9Eu:APA91bHKNdel2CrgIScNS4TMbFvIhqKAYZMrfF41KEpSpNlWG1gQk9JH9ng2_eThwLYRBD0sLk2gpuInixUB3Sqcx3kYGvyiRy8m6NZgSclkwlYaHyvymODwBD93YPE33TABIKORZvmj", // Replace with the actual device token
    'notification' => array(
      'title' => "New data inserted",
      'body' => "Data with ID 11 is added.",
    ),
  );

  // Set options for FCM request
  $headers = array(
    'Authorization: AAAArCbshoc:APA91bE5UpryzF8vUsGcvKhVAbKpAKVHGKTm9-Tbb91tTp7kD_qvJuC9rLxZETWQjQFs06kKU0z-l4KDi6uEJxDuanVJgm9RjOoFNP5dv6ttZ4o82JoYx7C4QO2W25Umj5nxdHtLd-at', // Replace with your FCM server key
    'Content-Type: application/json',
  );

  $options = array(
    CURLOPT_URL => 'https://fcm.googleapis.com/fcm/send',
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => json_encode($body),
  );

  // Initialize cURL session
  $ch = curl_init();
  curl_setopt_array($ch, $options);

  // Execute cURL session and get the response
  $response = curl_exec($ch);

  // Check for cURL errors
  if (curl_errno($ch)) {
    echo 'Error sending cURL request: ' . curl_error($ch);
  }

  // Close cURL session
  curl_close($ch);

  // Check response and log
  if ($response) {
    echo "Notifications sent successfully.";
  } else {
    echo "Error sending notifications: No response received.";
  }
}

sendNotifications();
?>

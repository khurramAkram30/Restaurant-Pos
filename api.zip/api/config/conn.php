<?php
$conn=mysqli_connect("localhost","root","","pos");
if($conn){
    // echo "connected";
}
?>